function sendMessage() {
    const message = document.getElementById("userMessage").value;
    const output = document.getElementById("messageOutput");
    output.innerHTML = `<p>Pesan untuk Babyy: ${message}</p>`;
    document.getElementById("userMessage").value = ''; // Mengosongkan textarea setelah mengirim
}
